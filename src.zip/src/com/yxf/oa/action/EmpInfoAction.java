package com.yxf.oa.action;
/**
*
* @author yxf
* @time 2018年8月28日上午11:24:45
*
*/
public class EmpInfoAction {
	
	public String turnToInfo(){
		
		return "success";
	}
	
}
