package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年8月31日下午2:11:57
*
*/
@Controller("turnToClockOutAction")
public class TurnToClockOutAction {
	
	public String turnToClockOut(){
		
		return "success";
	}
	
}
