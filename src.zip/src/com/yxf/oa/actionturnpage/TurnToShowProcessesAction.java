package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年9月1日下午3:07:50
*
*/
@Controller("turnToShowProcessesAction")
public class TurnToShowProcessesAction {
	
	public String turnToShowProcesses(){
		
		return "success";
	}
	
}
