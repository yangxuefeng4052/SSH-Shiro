package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年8月29日下午7:40:33
*
*/
@Controller("turnToCreateEmp")
public class TurnToCreateEmp {
	
	public String turnToCreateEmp(){
		
		return "success";
	}
	
}
