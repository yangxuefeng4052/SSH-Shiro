package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年8月31日下午2:11:57
*
*/
@Controller("turnToClockInAction")
public class TurnToClockInAction {
	
	public String turnToClockIn(){
		
		return "success";
	}
	
}
