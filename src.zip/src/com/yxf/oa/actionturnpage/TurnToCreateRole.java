package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年8月29日上午10:06:06
*
*/
@Controller("turnToCreateRole")
public class TurnToCreateRole {
	
	public String turnToCreateRole(){
		
		return "success";
	}
	
}
