package com.yxf.oa.actionturnpage;

import org.springframework.stereotype.Controller;

/**
*
* @author yxf
* @time 2018年9月4日上午9:47:35
*
*/
@Controller("turnToNotice")
public class TurnToNotice {
	public String turnToNotice(){
		
		return "success";
	}
}
